int one_plus(int a) {
  return 1 + a;
}
